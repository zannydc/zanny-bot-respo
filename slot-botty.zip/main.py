import discord
from discord.ext import commands, tasks
from datetime import datetime, timedelta

bot = commands.Bot(command_prefix='.', intents=discord.Intents.all())
mention_count = {}
reset_time = datetime.now().replace(hour=4, minute=27, second=50, microsecond=0)

statuses = ["lets check the bot"]

@tasks.loop(seconds=5)  # Change status every 5 seconds
async def change_status():
    new_status = statuses.pop(0)  # Get the first status
    statuses.append(new_status)  # Move the current status to the end of the list
    await bot.change_presence(activity=discord.Activity(type=discord.ActivityType.watching, name=new_status))

@bot.event
async def on_ready():
    print(f'We Have Connected As {bot.user}')
    print('- Hyperservice ')
    reset_mentions.start()
    change_status.start()

@tasks.loop(seconds=60)  # Check every minute
async def reset_mentions():
    global mention_count, reset_time

    now = datetime.now()
    if now > reset_time:
        mention_count = {}
        reset_time = now + timedelta(days=1)

@bot.event
async def on_message(message):
    if message.author.bot:
        return

    if "@everyone" in message.content and not message.author.guild_permissions.administrator and message.channel.category_id == 1274797481829597307:
        channel = message.channel
        user = message.author
        await channel.set_permissions(user,
                                      send_messages=False,
                                      read_message_history=False,
                                      mention_everyone=False)
        await channel.send(f"Revoked Slot | Reason: Everyone ping")
        await user.create_dm()
        await user.send('Revoked Slot | Reason: Everyone ping')
        return

    if "@everyone" in message.content and message.author.guild_permissions.administrator and message.channel.category_id == 1274797481829597307:
        await message.channel.send('Cant revoke Slot, User is Admin')
        return

    global mention_count

    # Check if the message contains a mention of @here
    if "@here" in message.content and message.channel.category_id == 1274797481829597307:
        mention_count["overall"] = mention_count.get("overall", 0) + 1
        mention_count[message.author.id] = mention_count.get(message.author.id, 0) + 1

        embed = discord.Embed(
            description=f'**{message.author.mention}, YOU USED** __**{mention_count[message.author.id]}/3**__ **PINGS**. | __**USE MM TO BE SAFE!**__',
            color=0x2f3136)
        na = await message.channel.send(embed=embed)

        if mention_count.get(message.author.id, 0) > 3:
            # Remove send message permission from the channel and send a notification
            await message.channel.set_permissions(message.author, send_messages=False)
            embed = discord.Embed(
                description=f"**{message.author.mention}, Your Slot Has been Revoked for Using 4x Here Pings.**",
                color=0x2f3136)

            await na.delete()
            await message.channel.send(embed=embed)

    await bot.process_commands(message)

@bot.command()
@commands.has_permissions(administrator=True)
async def slot(ctx, user: discord.Member, slot_name: str, duration: str = '1w'):
    category_id = 1202333347431600138
    category = discord.utils.get(ctx.guild.categories, id=1274797481829597307)

    channel = await category.create_text_channel(slot_name)

    # Set default permissions
    await channel.set_permissions(ctx.guild.default_role,
                                  view_channel=True,
                                  send_messages=False)
    await channel.set_permissions(user,
                                  view_channel=True,
                                  send_messages=True,
                                  mention_everyone= True)

    # Parse duration and calculate expiry date
    if duration.endswith('w'):
        duration_days = int(duration[:-1]) * 7
        duration_text = f"{int(duration[:-1])} weeks"
    elif duration.endswith('m'):
        duration_days = int(duration[:-1]) * 30
        duration_text = f"{int(duration[:-1])} months"
    else:
        duration_days = int(duration)
        duration_text = f"{duration_days} days"

    purchase_date = datetime.utcnow()
    expiry_date = purchase_date + timedelta(days=duration_days)

    embed = discord.Embed(
        title="Slot Channel Created",
        description=f"Slot channel for {user.mention} has been created.",
        color=discord.Color.green()
    )
    await ctx.send(embed=embed)

    embed2 = discord.Embed(
        title="Hyper SLOT RULES",
        description="""**➥ 3 here ping per day.
➥ No everyone Ping or role ping. 
➥ No Refund on private slot. 
➥ You can't sell your slot. 
➥ You can't share your slot. 
➥ Any Kind of promotion is not allowed.
➥ No advertising Allowed - Only autobuy link !.
➥ You can ping @here 2 times per day to your slot. This day is based on Eu Time Zone.
➥ So don't ping based on your country time.
➥ If you disobey any of these rules, Slot will be revoked without refund. 

Scam = Slot revoke Without refund**
""",
        color=0x2f3136)
    await channel.send(embed=embed2)

    # Create slot details embed
    embed3 = discord.Embed(
        title="Hyper Slot Details",
        description=f"**Purchase Date:** {purchase_date.strftime('%d-%m')}\n"
                    f"**Duration:** **{duration_days} days | {duration_text}**\n"
                    f"**Expiry Date:** {expiry_date.strftime('%d-%m')}",
        color=discord.Color.green()
    )
    embed3.add_field(name="Permissions",
                    value="```3X @here pings```",
                    inline=False)
    embed3.add_field(name="Rule 1",
                    value="**Must** follow the slot rules strictly.",
                    inline=False)
    embed3.add_field(name="Rule 2",
                    value="**Must** Always accept MM.",
                    inline=False)

    await channel.send(embed=embed3)
    

@bot.command()
@commands.has_permissions(administrator=True)
async def revoke(ctx, user: discord.User, channel: discord.TextChannel = None):
    channel = channel or ctx.channel
    
    # Remove send message permission
    await channel.set_permissions(user, send_messages=False)

    embed = discord.Embed(
        title="Slot Revoked",
        description=f"Revoked {user.mention}'s Slot.",
        color=discord.Color.red()
    )
    await ctx.send(embed=embed)

@bot.command()
@commands.has_permissions(administrator=True)
async def hold(ctx, user: discord.User, channel: discord.TextChannel = None):
    channel = channel or ctx.channel
    
    # Remove send message permission
    await channel.set_permissions(user, send_messages=False)
    
    embed = discord.Embed(
        title="Slot On Hold !",
        description=f"{user.mention}'s Slot is On Hold Now, Don`t deal till its solved!",
        color=discord.Color.orange()
    )
    await ctx.send(embed=embed)

@bot.command()
@commands.has_permissions(administrator=True)
async def add(ctx, user: discord.User, channel: discord.TextChannel = None):
    channel = channel or ctx.channel
    
    # Add send message, embed links, and mention everyone permissions
    await channel.set_permissions(user, send_messages=True, embed_links=True, mention_everyone=True, view_channel=True)
    
    embed = discord.Embed(
        title="User Added",
        description=f"Added {user.mention} in {channel.mention}",
        color=discord.Color.blue()
    )
    await ctx.send(embed=embed)

@bot.command()
@commands.has_permissions(administrator=True)
async def srules(ctx, channel: discord.TextChannel = None):
  if channel is None:
    # If no channel is mentioned, use the channel where the command was invoked
    channel = ctx.channel

  embed = discord.Embed(title='Hyper SLOT RULES',
                        description="""**➥ 3 here ping per day.
➥ No everyone Ping or role ping. 
➥ No Refund on private slot. 
➥ You can't sell your slot. 
➥ You can't share your slot. 
➥ Any Kind of promotion is not allowed.
➥ Gambling/Money doubling not allowed.
➥ No Advertising Allowed - Only Autobuy link.
➥ You can ping @here 2 times per day to your slot. This day is based on Eu Time Zone).
➥ So don't ping based on your country time.
➥ If you disobey any of these rules, Slot will be revoked without refund. 

Scam = Slot revoke Without refund**
**Made By ZeXo**
""",
                        color=0xBF40BF)
  await channel.send(embed=embed)

bot.run('MTEzODY1MDIzOTgzMDU5Nzc2Mg.G8sIcx.YfifBSf_f7oqyfiDC-GQvRTcntvYUuv_ZC3Y9U')

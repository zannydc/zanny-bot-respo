Slot Bot Source Code

Increse your server experience

First of all Hosting you can host at Pyles Node 
After at server upload files after open main.py in that there are 4 lines in that you have to edit the channel slot cateroy 23 26 28 32 somthing this lines 
After to beloa at end of the code after add your bot token and start the server 

After add bot in your sserver and do .help 

support ? - fkbrokies2.0 or